CREATE PROCEDURE ResetSubAccount(AccountId Number,SubAccountIndex Number,ResetSum integer)
IS
 --объявление переменных для осуществления проверок
 accountSum integer;
 subaccountsSum integer;
 countSubAccountWithIndexes number;
 countAccounts number;
 subAccountIdHolder number;
BEGIN
   --заполняем переменные
   --Переменная для проверки совпадений в таблице подсчетов с таким же индексом
    SELECT count(*) into countSubAccountWithIndexes FROM SUBACCOUNT where SUBACCOUNT.ACCOUNT_ID=AccountId and SUBACCOUNT.SUBACCOUNT_INDEX=SubAccountIndex;
   --Переменная для проверки совпадений в таблице счетов 
    SELECT count(*) into countAccounts FROM ACCOUNT WHERE ACCOUNT_ID=AccountId;
   --Если подсчета нет
   IF countSubAccountWithIndexes=0 THEN
   --Если счет отсутствует, то выходим
      IF countAccounts=0 THEN
        RETURN;
  --Если счет присутствует, то вставляем новую запись подсчета, с необходимым индексом.
      ELSE
        INSERT INTO SUBACCOUNT(SUBACCOUNT_INDEX,SUBACCOUNT_SUM,ACCOUNT_ID) VALUES(SubAccountIndex,ResetSum,AccountId);
        --обновляем переменные после вставки
         --Переменная для проверки суммы в таблице аккаунта
         --SELECT ACCOUNT_SUM into accountSum FROM ACCOUNT WHERE ACCOUNT_ID=AccountId;
         --Переменная для проверки суммы по подсчетам в таблице подсчетов
         SELECT SUM(SUBACCOUNT_SUM) INTO subaccountsSum FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId;
        --Изменяем сумму в аккаунте, если это надо
       /* IF accountSum<subaccountsSum THEN*/
        UPDATE ACCOUNT SET ACCOUNT_SUM=subaccountsSum WHERE ACCOUNT_ID=AccountId;
        --Добавляем запись в таблицу сбросов
        SELECT SUBACCOUNT_ID INTO subAccountIdHolder FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId AND SUBACCOUNT_INDEX=SubAccountIndex;
        INSERT INTO RESETS (RESET_SUM,RESET_DATE,SUBACCOUNT_ID) VALUES(ResetSum,SYSTIMESTAMP,subAccountIdHolder);
       -- END IF;
      END IF;
   ELSE
   --Если подсчет есть
   --Обновляем его сумму
     UPDATE SUBACCOUNT SET SUBACCOUNT_SUM=ResetSum WHERE SUBACCOUNT_INDEX=SubAccountIndex AND ACCOUNT_ID=AccountId;
     --Переменная для проверки суммы в таблице аккаунта
       -- SELECT ACCOUNT_SUM into accountSum FROM ACCOUNT WHERE ACCOUNT_ID=AccountId;
         --Переменная для проверки суммы по подсчетам в таблице подсчетов
    SELECT SUM(SUBACCOUNT_SUM) INTO subaccountsSum FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId;
       UPDATE ACCOUNT SET ACCOUNT_SUM=subaccountsSum WHERE ACCOUNT_ID=AccountId;
       --Добавляем запись в таблицу сбросов
       SELECT SUBACCOUNT_ID INTO subAccountIdHolder FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId AND SUBACCOUNT_INDEX=SubAccountIndex;
        INSERT INTO RESETS (RESET_SUM,RESET_DATE,SUBACCOUNT_ID) VALUES(ResetSum,SYSTIMESTAMP,subAccountIdHolder);
   END IF;
END;
/
