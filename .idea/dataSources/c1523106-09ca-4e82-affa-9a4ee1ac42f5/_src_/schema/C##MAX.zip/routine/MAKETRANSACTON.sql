CREATE PROCEDURE MakeTransacton(AccountId number,TransactionSum Integer)
IS
--переменная для подсчета записи счета
countAccountId number;
--переменная для суммы аккаунта
accountSum integer;
--переменная для подсчета суммы подсчетов
subAccountsSum integer;
--переменная для id транзакции
transactionId number;
--переменная для id подсчета
subAccountId number;
marker integer;
subAccountIdHolder number;
subAccountIndexHolder number;
subAccountSumHolder integer;
AccountIdHolder number;

--Курсор для получения всех подсчетов с суммой выше нуля
CURSOR subAccountsWithValue
IS
SELECT * FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId AND SUBACCOUNT_SUM>0 ORDER BY(SUBACCOUNT_INDEX) DESC;

BEGIN
SELECT COUNT(*) into countAccountId FROM ACCOUNT WHERE ACCOUNT_ID=AccountId;
IF countAccountId>0 THEN
   SELECT ACCOUNT_SUM into accountSum FROM ACCOUNT where ACCOUNT_ID=AccountId;
   IF TransactionSum>0 THEN
     --обновляем подсчет с индексом 1
     UPDATE SUBACCOUNT SET SUBACCOUNT_SUM=SUBACCOUNT_SUM+TransactionSum WHERE ACCOUNT_ID=AccountId AND SUBACCOUNT_INDEX=1;
     SELECT SUM(SUBACCOUNT_SUM) INTO subAccountsSum FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId;
     --обновляем сумму счета
     UPDATE ACCOUNT SET ACCOUNT_SUM=subAccountsSum where ACCOUNT_ID=AccountId;
     --Добавляем в таблицу переводов
     INSERT INTO TRANSACTION(TRANSACTION_SUM,TRANSACTION_DATE,ACCOUNT_ID) VALUES(TransactionSum,SYSTIMESTAMP,AccountId);
     --Получаем ID Транзакции
     SELECT MAX(TRANSACTION_ID) INTO transactionId FROM TRANSACTION;
     --Получаем ID Подсчета
     SELECT SUBACCOUNT_ID into subAccountId FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId AND SUBACCOUNT_INDEX=1;
     --Добавляем запись в таблицу разбивок
     INSERT INTO TRANSACTION_PARTS(PART_SUM,TRANSACTION_ID,SUBACCOUNT_ID) VALUES(TransactionSum,transactionId,subAccountId);
   ELSIF TransactionSum<0 AND ABS(TransactionSum)<=accountSum THEN
   --списываем с подсчетов в порядке уменьщения индексов и записываем изменения в таблицу разбивок и переводов.
   OPEN subAccountsWithValue;
   --Добавляем в таблицу переводов
   INSERT INTO TRANSACTION(TRANSACTION_SUM,TRANSACTION_DATE,ACCOUNT_ID) VALUES(TransactionSum,SYSTIMESTAMP,AccountId);
   marker:=TransactionSum;
   LOOP
   FETCH subAccountsWithValue into subAccountIdHolder,subAccountIndexHolder,subAccountSumHolder,accountIdHolder;
       IF ABS(marker)<=SubAccountSumHolder THEN
         --Обновили подсчет
         UPDATE SUBACCOUNT SET SUBACCOUNT_SUM=SUBACCOUNT_SUM-ABS(marker) where SUBACCOUNT_ID=subAccountIdHolder;
         SELECT SUM(SUBACCOUNT_SUM) INTO subAccountsSum FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId;
         --обновляем сумму счета
         UPDATE ACCOUNT SET ACCOUNT_SUM=subAccountsSum where ACCOUNT_ID=AccountId;
         --Получаем ID Транзакции
         SELECT MAX(TRANSACTION_ID) INTO transactionId FROM TRANSACTION;
         --Получаем ID Подсчета
         SELECT SUBACCOUNT_ID into subAccountId FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId AND SUBACCOUNT_INDEX=1;
         --Добавляем запись в таблицу разбивок
         INSERT INTO TRANSACTION_PARTS(PART_SUM,TRANSACTION_ID,SUBACCOUNT_ID) VALUES(marker,transactionId,subAccountId);
         marker:=0;
         --TransactionSum:=TransactionSum-TransactionSum;
       ELSIF ABS(marker)>SubAccountSumHolder THEN
         --Обновить подсчет
         UPDATE SUBACCOUNT SET SUBACCOUNT_SUM=0 where SUBACCOUNT_ID=subAccountIdHolder;
         SELECT SUM(SUBACCOUNT_SUM) INTO subAccountsSum FROM SUBACCOUNT WHERE ACCOUNT_ID=AccountId;
         --обновляем сумму счета
         UPDATE ACCOUNT SET ACCOUNT_SUM=subAccountsSum where ACCOUNT_ID=AccountId;
         --Получаем ID Транзакции
         SELECT MAX(TRANSACTION_ID) INTO transactionId FROM TRANSACTION;
         --Добавляем запись в таблицу разбивок
         INSERT INTO TRANSACTION_PARTS(PART_SUM,TRANSACTION_ID,SUBACCOUNT_ID) VALUES(-subAccountSumHolder,transactionId,subAccountIdHolder);
         marker:=marker+subAccountSumHolder;
       END IF;

       EXIT WHEN marker=0;
   END LOOP;

   END IF;
END IF;
END;
/
